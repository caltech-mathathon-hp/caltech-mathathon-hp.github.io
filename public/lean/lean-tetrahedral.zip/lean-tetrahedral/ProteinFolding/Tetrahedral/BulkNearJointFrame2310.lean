import ProteinFolding.Tetrahedral.BulkNearJointFrameSpec
import ProteinFolding.Tetrahedral.BulkNearJointRowCases

namespace ProteinFolding.Tetrahedral

set_option maxRecDepth 100000
set_option maxHeartbeats 24000000

private theorem jointRow_2310_0f0 : BulkNearJointRowCheck bulkNearJointFrame2310 0 false 0 := by
  decide +kernel

private theorem jointRow_2310_0f1 : BulkNearJointRowCheck bulkNearJointFrame2310 0 false 1 := by
  decide +kernel

private theorem jointRow_2310_0f2 : BulkNearJointRowCheck bulkNearJointFrame2310 0 false 2 := by
  decide +kernel

private theorem jointRow_2310_0f3 : BulkNearJointRowCheck bulkNearJointFrame2310 0 false 3 := by
  decide +kernel

private theorem jointRow_2310_0t0 : BulkNearJointRowCheck bulkNearJointFrame2310 0 true 0 := by
  decide +kernel

private theorem jointRow_2310_0t1 : BulkNearJointRowCheck bulkNearJointFrame2310 0 true 1 := by
  decide +kernel

private theorem jointRow_2310_0t2 : BulkNearJointRowCheck bulkNearJointFrame2310 0 true 2 := by
  decide +kernel

private theorem jointRow_2310_0t3 : BulkNearJointRowCheck bulkNearJointFrame2310 0 true 3 := by
  decide +kernel

private theorem jointRow_2310_1f0 : BulkNearJointRowCheck bulkNearJointFrame2310 1 false 0 := by
  decide +kernel

private theorem jointRow_2310_1f1 : BulkNearJointRowCheck bulkNearJointFrame2310 1 false 1 := by
  decide +kernel

private theorem jointRow_2310_1f2 : BulkNearJointRowCheck bulkNearJointFrame2310 1 false 2 := by
  decide +kernel

private theorem jointRow_2310_1f3 : BulkNearJointRowCheck bulkNearJointFrame2310 1 false 3 := by
  decide +kernel

private theorem jointRow_2310_1t0 : BulkNearJointRowCheck bulkNearJointFrame2310 1 true 0 := by
  decide +kernel

private theorem jointRow_2310_1t1 : BulkNearJointRowCheck bulkNearJointFrame2310 1 true 1 := by
  decide +kernel

private theorem jointRow_2310_1t2 : BulkNearJointRowCheck bulkNearJointFrame2310 1 true 2 := by
  decide +kernel

private theorem jointRow_2310_1t3 : BulkNearJointRowCheck bulkNearJointFrame2310 1 true 3 := by
  decide +kernel

private theorem jointRow_2310_2f0 : BulkNearJointRowCheck bulkNearJointFrame2310 2 false 0 := by
  decide +kernel

private theorem jointRow_2310_2f1 : BulkNearJointRowCheck bulkNearJointFrame2310 2 false 1 := by
  decide +kernel

private theorem jointRow_2310_2f2 : BulkNearJointRowCheck bulkNearJointFrame2310 2 false 2 := by
  decide +kernel

private theorem jointRow_2310_2f3 : BulkNearJointRowCheck bulkNearJointFrame2310 2 false 3 := by
  decide +kernel

private theorem jointRow_2310_2t0 : BulkNearJointRowCheck bulkNearJointFrame2310 2 true 0 := by
  decide +kernel

private theorem jointRow_2310_2t1 : BulkNearJointRowCheck bulkNearJointFrame2310 2 true 1 := by
  decide +kernel

private theorem jointRow_2310_2t2 : BulkNearJointRowCheck bulkNearJointFrame2310 2 true 2 := by
  decide +kernel

private theorem jointRow_2310_2t3 : BulkNearJointRowCheck bulkNearJointFrame2310 2 true 3 := by
  decide +kernel

private theorem jointRow_2310_3f0 : BulkNearJointRowCheck bulkNearJointFrame2310 3 false 0 := by
  decide +kernel

private theorem jointRow_2310_3f1 : BulkNearJointRowCheck bulkNearJointFrame2310 3 false 1 := by
  decide +kernel

private theorem jointRow_2310_3f2 : BulkNearJointRowCheck bulkNearJointFrame2310 3 false 2 := by
  decide +kernel

private theorem jointRow_2310_3f3 : BulkNearJointRowCheck bulkNearJointFrame2310 3 false 3 := by
  decide +kernel

private theorem jointRow_2310_3t0 : BulkNearJointRowCheck bulkNearJointFrame2310 3 true 0 := by
  decide +kernel

private theorem jointRow_2310_3t1 : BulkNearJointRowCheck bulkNearJointFrame2310 3 true 1 := by
  decide +kernel

private theorem jointRow_2310_3t2 : BulkNearJointRowCheck bulkNearJointFrame2310 3 true 2 := by
  decide +kernel

private theorem jointRow_2310_3t3 : BulkNearJointRowCheck bulkNearJointFrame2310 3 true 3 := by
  decide +kernel

private theorem jointRow_2310_4f0 : BulkNearJointRowCheck bulkNearJointFrame2310 4 false 0 := by
  decide +kernel

private theorem jointRow_2310_4f1 : BulkNearJointRowCheck bulkNearJointFrame2310 4 false 1 := by
  decide +kernel

private theorem jointRow_2310_4f2 : BulkNearJointRowCheck bulkNearJointFrame2310 4 false 2 := by
  decide +kernel

private theorem jointRow_2310_4f3 : BulkNearJointRowCheck bulkNearJointFrame2310 4 false 3 := by
  decide +kernel

private theorem jointRow_2310_4t0 : BulkNearJointRowCheck bulkNearJointFrame2310 4 true 0 := by
  decide +kernel

private theorem jointRow_2310_4t1 : BulkNearJointRowCheck bulkNearJointFrame2310 4 true 1 := by
  decide +kernel

private theorem jointRow_2310_4t2 : BulkNearJointRowCheck bulkNearJointFrame2310 4 true 2 := by
  decide +kernel

private theorem jointRow_2310_4t3 : BulkNearJointRowCheck bulkNearJointFrame2310 4 true 3 := by
  decide +kernel

private theorem jointRow_2310_5f0 : BulkNearJointRowCheck bulkNearJointFrame2310 5 false 0 := by
  decide +kernel

private theorem jointRow_2310_5f1 : BulkNearJointRowCheck bulkNearJointFrame2310 5 false 1 := by
  decide +kernel

private theorem jointRow_2310_5f2 : BulkNearJointRowCheck bulkNearJointFrame2310 5 false 2 := by
  decide +kernel

private theorem jointRow_2310_5f3 : BulkNearJointRowCheck bulkNearJointFrame2310 5 false 3 := by
  decide +kernel

private theorem jointRow_2310_5t0 : BulkNearJointRowCheck bulkNearJointFrame2310 5 true 0 := by
  decide +kernel

private theorem jointRow_2310_5t1 : BulkNearJointRowCheck bulkNearJointFrame2310 5 true 1 := by
  decide +kernel

private theorem jointRow_2310_5t2 : BulkNearJointRowCheck bulkNearJointFrame2310 5 true 2 := by
  decide +kernel

private theorem jointRow_2310_5t3 : BulkNearJointRowCheck bulkNearJointFrame2310 5 true 3 := by
  decide +kernel

private theorem jointRow_2310_6f0 : BulkNearJointRowCheck bulkNearJointFrame2310 6 false 0 := by
  decide +kernel

private theorem jointRow_2310_6f1 : BulkNearJointRowCheck bulkNearJointFrame2310 6 false 1 := by
  decide +kernel

private theorem jointRow_2310_6f2 : BulkNearJointRowCheck bulkNearJointFrame2310 6 false 2 := by
  decide +kernel

private theorem jointRow_2310_6f3 : BulkNearJointRowCheck bulkNearJointFrame2310 6 false 3 := by
  decide +kernel

private theorem jointRow_2310_6t0 : BulkNearJointRowCheck bulkNearJointFrame2310 6 true 0 := by
  decide +kernel

private theorem jointRow_2310_6t1 : BulkNearJointRowCheck bulkNearJointFrame2310 6 true 1 := by
  decide +kernel

private theorem jointRow_2310_6t2 : BulkNearJointRowCheck bulkNearJointFrame2310 6 true 2 := by
  decide +kernel

private theorem jointRow_2310_6t3 : BulkNearJointRowCheck bulkNearJointFrame2310 6 true 3 := by
  decide +kernel

private theorem jointRow_2310_7f0 : BulkNearJointRowCheck bulkNearJointFrame2310 7 false 0 := by
  decide +kernel

private theorem jointRow_2310_7f1 : BulkNearJointRowCheck bulkNearJointFrame2310 7 false 1 := by
  decide +kernel

private theorem jointRow_2310_7f2 : BulkNearJointRowCheck bulkNearJointFrame2310 7 false 2 := by
  decide +kernel

private theorem jointRow_2310_7f3 : BulkNearJointRowCheck bulkNearJointFrame2310 7 false 3 := by
  decide +kernel

private theorem jointRow_2310_7t0 : BulkNearJointRowCheck bulkNearJointFrame2310 7 true 0 := by
  decide +kernel

private theorem jointRow_2310_7t1 : BulkNearJointRowCheck bulkNearJointFrame2310 7 true 1 := by
  decide +kernel

private theorem jointRow_2310_7t2 : BulkNearJointRowCheck bulkNearJointFrame2310 7 true 2 := by
  decide +kernel

private theorem jointRow_2310_7t3 : BulkNearJointRowCheck bulkNearJointFrame2310 7 true 3 := by
  decide +kernel

private theorem jointRow_2310_8f0 : BulkNearJointRowCheck bulkNearJointFrame2310 8 false 0 := by
  decide +kernel

private theorem jointRow_2310_8f1 : BulkNearJointRowCheck bulkNearJointFrame2310 8 false 1 := by
  decide +kernel

private theorem jointRow_2310_8f2 : BulkNearJointRowCheck bulkNearJointFrame2310 8 false 2 := by
  decide +kernel

private theorem jointRow_2310_8f3 : BulkNearJointRowCheck bulkNearJointFrame2310 8 false 3 := by
  decide +kernel

private theorem jointRow_2310_8t0 : BulkNearJointRowCheck bulkNearJointFrame2310 8 true 0 := by
  decide +kernel

private theorem jointRow_2310_8t1 : BulkNearJointRowCheck bulkNearJointFrame2310 8 true 1 := by
  decide +kernel

private theorem jointRow_2310_8t2 : BulkNearJointRowCheck bulkNearJointFrame2310 8 true 2 := by
  decide +kernel

private theorem jointRow_2310_8t3 : BulkNearJointRowCheck bulkNearJointFrame2310 8 true 3 := by
  decide +kernel

private theorem jointRow_2310_9f0 : BulkNearJointRowCheck bulkNearJointFrame2310 9 false 0 := by
  decide +kernel

private theorem jointRow_2310_9f1 : BulkNearJointRowCheck bulkNearJointFrame2310 9 false 1 := by
  decide +kernel

private theorem jointRow_2310_9f2 : BulkNearJointRowCheck bulkNearJointFrame2310 9 false 2 := by
  decide +kernel

private theorem jointRow_2310_9f3 : BulkNearJointRowCheck bulkNearJointFrame2310 9 false 3 := by
  decide +kernel

private theorem jointRow_2310_9t0 : BulkNearJointRowCheck bulkNearJointFrame2310 9 true 0 := by
  decide +kernel

private theorem jointRow_2310_9t1 : BulkNearJointRowCheck bulkNearJointFrame2310 9 true 1 := by
  decide +kernel

private theorem jointRow_2310_9t2 : BulkNearJointRowCheck bulkNearJointFrame2310 9 true 2 := by
  decide +kernel

private theorem jointRow_2310_9t3 : BulkNearJointRowCheck bulkNearJointFrame2310 9 true 3 := by
  decide +kernel

theorem bulkNearJoint_position_row_frame_2310 (t : Fin 10) (odd : Bool) (d : Fin 4) :
    BulkNearJointRowCheck bulkNearJointFrame2310 t odd d := by
  exact bulkNearJointRow_cases (fun t odd d => BulkNearJointRowCheck bulkNearJointFrame2310 t odd d)
    jointRow_2310_0f0
    jointRow_2310_0f1
    jointRow_2310_0f2
    jointRow_2310_0f3
    jointRow_2310_0t0
    jointRow_2310_0t1
    jointRow_2310_0t2
    jointRow_2310_0t3
    jointRow_2310_1f0
    jointRow_2310_1f1
    jointRow_2310_1f2
    jointRow_2310_1f3
    jointRow_2310_1t0
    jointRow_2310_1t1
    jointRow_2310_1t2
    jointRow_2310_1t3
    jointRow_2310_2f0
    jointRow_2310_2f1
    jointRow_2310_2f2
    jointRow_2310_2f3
    jointRow_2310_2t0
    jointRow_2310_2t1
    jointRow_2310_2t2
    jointRow_2310_2t3
    jointRow_2310_3f0
    jointRow_2310_3f1
    jointRow_2310_3f2
    jointRow_2310_3f3
    jointRow_2310_3t0
    jointRow_2310_3t1
    jointRow_2310_3t2
    jointRow_2310_3t3
    jointRow_2310_4f0
    jointRow_2310_4f1
    jointRow_2310_4f2
    jointRow_2310_4f3
    jointRow_2310_4t0
    jointRow_2310_4t1
    jointRow_2310_4t2
    jointRow_2310_4t3
    jointRow_2310_5f0
    jointRow_2310_5f1
    jointRow_2310_5f2
    jointRow_2310_5f3
    jointRow_2310_5t0
    jointRow_2310_5t1
    jointRow_2310_5t2
    jointRow_2310_5t3
    jointRow_2310_6f0
    jointRow_2310_6f1
    jointRow_2310_6f2
    jointRow_2310_6f3
    jointRow_2310_6t0
    jointRow_2310_6t1
    jointRow_2310_6t2
    jointRow_2310_6t3
    jointRow_2310_7f0
    jointRow_2310_7f1
    jointRow_2310_7f2
    jointRow_2310_7f3
    jointRow_2310_7t0
    jointRow_2310_7t1
    jointRow_2310_7t2
    jointRow_2310_7t3
    jointRow_2310_8f0
    jointRow_2310_8f1
    jointRow_2310_8f2
    jointRow_2310_8f3
    jointRow_2310_8t0
    jointRow_2310_8t1
    jointRow_2310_8t2
    jointRow_2310_8t3
    jointRow_2310_9f0
    jointRow_2310_9f1
    jointRow_2310_9f2
    jointRow_2310_9f3
    jointRow_2310_9t0
    jointRow_2310_9t1
    jointRow_2310_9t2
    jointRow_2310_9t3
    t odd d

theorem bulkNearJoint_position_frame_2310 (t : Fin 10) (odd : Bool) (d e : Fin 4) :
    BulkNearJointPositionCheck bulkNearJointFrame2310 t odd d e :=
  bulkNearJointRowCheck_sound _ _ _ _ (bulkNearJoint_position_row_frame_2310 t odd d) e

end ProteinFolding.Tetrahedral
